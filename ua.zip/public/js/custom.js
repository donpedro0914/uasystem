$(document).ready(function() {

	$.ajaxSetup({
		headers: {
			'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		}
	});

	var baseurl=window.location.protocol + "//" + window.location.host + "/";

	//Plugins
	$('#datepicker-autoclose').datepicker({
        autoclose: true,
        todayHighlight: true
    });

	$('.date').datepicker({
        autoclose: true,
        todayHighlight: true
    });

    $(".select2").select2();


	$('.apply-btn').on('click', function(e) {

		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});

		e.preventDefault();
		var job_id = $(this).attr('data-id');
		var user_id = $(this).attr('data-user');

		swal({
			title: 'Are you sure you want to apply?',
			text: 'You can not undo once submitted',
			type: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes!'
		}).then((result) => {
		  if (result.value) {
		  	$.ajax({
				type:'POST',
				url: baseurl + 'applyjob',
				data:{'job_id':job_id,'user_id':user_id},
				success: function(data) {
					swal(
						'Done!',
						'You have successfully applied to this job!',
						'success'
					  )
					setTimeout(function() {
						location.reload();
					}, 500)
				}
			});
		  }
		});
	});

	//Delete Function
	$('.btn-delete').on('click', function(e) {

		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});

		e.preventDefault();

		swal({
			title: 'Are you sure?',
			text: 'You will not be able to recover this information!',
			type: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes!'
		}).then((result) => {
		if (result.value) {

			var id = $(e.currentTarget).attr('data-id');
			var name = $(e.currentTarget).attr('data-name');

			var url = document.location.origin + "/job/delete/" + id;
			var datatable = "ajax-jobs";
			

			var data = "id="+id;
			$.ajax({
				type: "DELETE",
				url: url,
				data: data,
				success: function(data) {
					$('.' + datatable).DataTable().row($(e.currentTarget).parents('tr')).remove().draw(false);
				}
			});

			swal('Deleted!', name + ' has been deleted', 'success');
		}
		});
	});

});
