<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('global.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('global.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div id="wrapper">
        <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <ol class="breadcrumb float-right">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">UA System</a></li>
                        <li class="breadcrumb-item">Jobs</li>
                        <li class="breadcrumb-item active"><?php echo e($job->job_title); ?></li>
                        </ol>
                        <h4 class="page-title"><?php echo e($job->job_title); ?></h4>
                    </div>
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card-box">
                                <form action="<?php echo e(route('jobs.update', ['id'=>$job->id])); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-row">
                                        <div class="col-8">
                                            <h5 class="col-12">Job Details</h5>
                                            <div class="row">
                                                <div class="form-group col-md-12 col-xs-12">
                                                    <label>Job Title</label>
                                                    <input type="text" class='form-control' name='title' value="<?php echo e($job->job_title); ?>" />
                                                </div>
                                                <div class="form-group col-md-12 col-xs-12">
                                                    <label>Company</label>
                                                    <input type="text" class='form-control' name='title' />
                                                </div>
                                                <div class="form-group col-md-12 col-xs-12">
                                                    <label>Job Description</label>
                                                    <textarea class="form-control" name='description'><?php echo e($job->job_description); ?></textarea>
                                                </div>
                                                <div class="form-group col-md-12 col-xs-12">
                                                    <label>Job Responsibilities</label>
                                                    <textarea class="form-control" name='responsibilities'><?php echo e($job->job_responsibilities); ?></textarea>
                                                </div>
                                                <div class="form-group col-md-12 col-xs-12">
                                                    <label>Job Requirements</label>
                                                    <textarea class="form-control" name='requiremnts'><?php echo e($job->job_requiremnts); ?></textarea>
                                                </div>
                                                <div class="form-group col-md-12 col-xs-12">
                                                    <label>Job Type</label>
                                                    <?php
                                                        $type = array(
                                                            'Grade School Faculty' => 'Grade School Faculty',
                                                            'Junior High School Faculty' => 'Junior High School Faculty',
                                                            'Senior High School Faculty' => 'Senior High School Faculty',
                                                            'College Faculty' => 'College Faculty'
                                                        );
                                                    ?>
                                                    <?php echo e(Form::select('type', $type, $job->job_type, ['class' => 'form-control'])); ?>

                                                </div>
                                                <div class="form-group col-md-12 col-xs-12">
                                                    <label>Job Status</label>
                                                    <?php
                                                        $status = array(
                                                            '1' => 'Active',
                                                            '0' => 'Inactive',
                                                        )
                                                    ?>
                                                    <?php echo e(Form::select('status', $status, $job->status, ['class' => 'form-control'])); ?>

                                                </div>
                                                <div class="form-group col-md-12 col-xs-12">
                                                    <div class="clearfix text-right mt-3">
                                                        <button type="submit" id="jobFormBtn" class="btn btn-success">
                                                            Update Job
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4 bg-dark">
                                            <div class="row">
                                                <h5 class="col-12 text-white">Applicants</h5>
                                                <ul>
                                                <?php $__currentLoopData = App\Applications::where('job_id', $job->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = App\User::where('id', $user->user_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><a href="#"><?php echo e($u->name); ?></a></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>