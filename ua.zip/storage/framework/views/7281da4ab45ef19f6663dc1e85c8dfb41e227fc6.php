<div id="addJob" class="modal fade" aria-labelledby="addTherapist">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Add Job</h4>
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
			</div>
			<div class="modal-body">
				<form id="menuForm" action="<?php echo e(route('jobs.store')); ?>" method="post" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<div class="form-row">
                        <h5 class="col-12">Job Information</h5>
                        <div class="col-12">
                            <div class="row">
                                <div class="form-group col-md-12 col-xs-12">
                                    <label>Job Title</label>
                                    <input type="text" class="form-control" name="title" placeholder="Enter job title.."/>
                                </div>
                                <div class="form-group col-md-12 col-xs-12">
                                    <label>Company</label>
									<select class="form-control" name="company">
										<option>-- Select Company --</option>
										<?php $__currentLoopData = App\Company::where('status', 1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($c->name); ?>"><?php echo e($c->name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
                                </div>
                                <div class="form-group col-md-12 col-xs-12">
                                    <label>Job Description</label>
                                    <textarea class="form-control" name="description"></textarea>
                                </div>
                                <div class="form-group col-md-12 col-xs-12">
                                    <label>Job Responsibilities</label>
                                    <textarea class="form-control" name="responsibilities"></textarea>
                                </div>
                                <div class="form-group col-md-12 col-xs-12">
                                    <label>Job Requirements</label>
                                    <textarea class="form-control" name="requiremnts"></textarea>
                                </div>
                                <div class="form-group col-md-12 col-xs-12">
                                    <label>Job Type</label>
                                    <select class="form-control" name="type">
										<option>-- Select Type --</option>
										<option value="Grade School Faculty">Grade School Faculty</option>
										<option value="Junior High School Faculty">Junior High School Faculty</option>
										<option value="Senior High School Faculty">Senior High School Faculty</option>
										<option value="College Faculty">College Faculty</option>
									</select>
                                </div>
                            </div>
                        </div>
						<div class="form-group col-md-12 col-xs-12">
							<div class="clearfix text-right mt-3">
								<button type="submit" id="addStoreBtn" class="btn btn-success">
									Add Job
								</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>