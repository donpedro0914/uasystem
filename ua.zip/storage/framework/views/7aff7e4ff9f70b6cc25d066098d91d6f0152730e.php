<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('global.front_topnav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="wrapper">
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-12">
                    <?php echo e(HTML::image('img/banner.png', 'UA', array('width'=>'100%'))); ?>

                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card-box">
                            <div class="info-container mt-4">
                                <div class="col-12">
                                    <h2>About the <?php echo e($job->job_title); ?></h2>
                                </div>
                                <div class="col-12">
                                    <span class="job_label">Job Title:</span> <?php echo e($job->job_title); ?>

                                </div>
                                <div class="col-12">
                                    <span class="job_label">Company</span> <?php echo e($job->company); ?>

                                </div>
                                <div class="col-12">
                                    <span class="job_label">Job Type:</span> <?php echo e($job->job_type); ?>

                                </div>
                                <div class="col-12">
                                    <span class="job_label">Job Description:</span> <?php echo e($job->job_description); ?>

                                </div>
                                <div class="col-12">
                                    <span class="job_label">Job Responsibilities:</span> <?php echo e($job->job_responsibilities); ?>

                                </div>
                                <div class="col-12">
                                    <span class="job_label">Job Requirements:</span> <?php echo e($job->job_requiremnts); ?>

                                </div>
                            </div>
                            <?php if(auth()->guard()->check()): ?>
                            <div class="apply-btn-container">
                                <a><button data-id="<?php echo e($job->id); ?>" data-user="<?php echo e(Auth::user()->id); ?>" class="apply-btn btn btn-primary">Apply Now</button></a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appfront', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>