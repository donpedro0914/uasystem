<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('global.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('global.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div id="wrapper">
	    <div class="content-page">
            <div class="content">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <ol class="breadcrumb float-right">
                            <li class="breadcrumb-item">Admin</li>
                            <li class="breadcrumb-item active">Job Hiring</li>
                        </ol>
                        <h4 class="page-title">Job Hiring</h4>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="card-box">
                                <button type="button" class="btn btn-primary waves-effect waves-light" data-toggle="modal" data-target="#addJob" data-animation="blur" data-overlayspeed="100" data-overlaycolor="#36404a">Add Job</button>
                                <?php echo $__env->make('modal.job', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card-box">
                            <div class="table-responsive" data-pattern="priority-columns">
                                <div class="sticky-table-header">
                                    <table id="table" class="table table-bordered dataTable no-footer table-striped ajax-jobs">
                                        <thead>
                                            <tr class="text-center">
                                                <th>Job Title</th>
                                                <th>Company</th>
                                                <th>Job Type</th>
                                                <th># of Applicants</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = App\Jobs::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="text-center">
                                                <td><?php echo e($j->job_title); ?></td>
                                                <td><?php echo e($j->company); ?></td>
                                                <td><?php echo e($j->job_type); ?></td>
                                                <?php $__empty_1 = true; $__currentLoopData = App\Applications::selectRaw('count(job_id) as totalCount')->where('job_id', $j->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <td><?php echo e($total->totalCount); ?></td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <td>0</td>
                                                <?php endif; ?>
                                                <td>
                                                    <?php if($j->status == 1): ?>
                                                            <span class="badge badge-primary">Active</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-danger">Inactive</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('jobs.edit', ['id'=>$j->id])); ?>" class="btn btn-xs btn-default btn-edit"><i class="mdi mdi-pencil"></i></a>
                                                    <a data-id="<?php echo e($j->id); ?>" data-name="<?php echo e($j->title); ?>" class="btn btn-xs btn-default btn-delete"><i class="text-danger mdi mdi-close-circle"></i></a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function() {

        $('#table').DataTable({
            keys: true
        });

        $("#summernote-editor").summernote({height:250,minHeight:null,maxHeight:null,focus:!1});

        var success = "<?php echo session('success'); ?>";
        var error = "<?php echo session('error'); ?>";

        if(success) {
            swal({
                position: 'middle-center',
                type: 'success',
                title: success,
                showConfirmButton: false,
                timer: 1000
            })
        }

        if(error) {
            swal({
                position: 'middle-center',
                type: 'error',
                title: error,
                showConfirmButton: false,
                timer: 1000
            })  
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>