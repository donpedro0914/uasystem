<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('global.front_topnav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="wrapper">
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-12">
                    <?php echo e(HTML::image('img/banner.png', 'UA', array('width'=>'100%'))); ?>

                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card-box">
                            <div class="hiring-list mt-4">
                                <h1 class="text-center">Our Openings</h1>
                                <p class="text-center">We have <?php echo e($jobCount); ?> Open Positions</p>
                                <ul class="hiring">
                                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="job">
                                        <div class="job-body">
                                            <a href="<?php echo e(route('jobs.info', ['id'=>$job->id])); ?>">
                                                <h5><?php echo e($job->job_title); ?></h5>
                                            </a>
                                            <span><b><?php echo e($job->company); ?></b></span><br>
                                            <span><?php echo e($job->job_type); ?></span>
                                        </div>
                                        <a href="<?php echo e(route('jobs.info', ['id'=>$job->id])); ?>">
                                            <button class="btn btn-primary">Apply</button>
                                        </a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appfront', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>