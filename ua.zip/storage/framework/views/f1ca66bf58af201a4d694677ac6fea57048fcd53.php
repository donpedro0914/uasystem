<?php $__env->startSection('content'); ?>
<section class="bg-account-pages">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="wrapper-page">
                    <div class="account-pages">
                        <div class="account-box">
                            <div class="account-logo-box">
                                <h2 class="text-uppercase text-center">
                                    <span><?php echo e(HTML::image('img/ua-logo.png', 'UA', array('style' => 'height:100%'))); ?></span>
                                </h2>
                            </div>
                            <div class="account-content">
                                <form method="POST" action="<?php echo e(route('login')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group mb-3">
                                        <label for="emailaddress" class="font-weight-medium">Username</label>
                                        <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" type="text" id="emailaddress" required="" placeholder="Enter your username">
                                        <?php if($errors->has('email')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group mb-3">
                                        <label for="password" class="font-weight-medium">Password</label>
                                        <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" type="password" required="" id="password" placeholder="Enter your password">
                                        <a href="#" class="text-muted float-right"><small>Forgot your password?</small></a>
                                        <?php if($errors->has('password')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group row text-center">
                                        <div class="col-12">
                                            <button class="btn btn-block btn-success waves-effect waves-light" type="submit">Sign In</button>
                                        </div>
                                    </div>
                                </form>
                                <div class="row mt-3">
                                    <div class="col-12 text-center">
                                        <p class="text-muted mb-0">
                                            Don't you have an account?
                                            <a class="reg-link text-dark ml-1" href="/register">Sign up</a>
                                        </p>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <p><a href="/">< back to homepage</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>