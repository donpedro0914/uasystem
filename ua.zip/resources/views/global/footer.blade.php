<footer class="footer">
	<div class="container-fluid">
		<div class="row">
			<div class="col-4">
				<h4 class="header-title">LOCATION</h4>
				<p>University of the Assumption<br>
					Unisite Subdivision,<br>
					Barangay Del Pilar,<br>
					City of San Fernando<br>
					Pampanga</p>
			</div>
			<div class="col-4">
				<h4 class="header-title">TELEPHONE</h4>
				<p>961-3617 loc 117-118 for queries</p>
			</div>
			<div class="col-4">
				<h4 class="header-title">EMAIL</h4>
				<p>uahrdoffice@ua.edu.ph</p>
			</div>
		</div>
	</div>
</footer>